Matlab library implemented by:
	Ghesini Matteo
	Toschi Anna
Updated to:
	13/06/2022
-----------------------------------------------------------------------
In the "Data" folder are contained three Matlab files containing our 
dataset to be used in case you are not using a computer with Windows, 
since readexcel.m would not run.
-----------------------------------------------------------------------
In the "Data" folder are contained a lot of folders in which are stored
all the results to be used by "Plotting.m".
-----------------------------------------------------------------------
"license_Roytest.txt" and "license_swtest.txt" are text file containing 
the license of the respectively two functions we had used and not 
implemented.
-----------------------------------------------------------------------
File "Saving_Data.m" and "Plotting.m" in folder "Unnecessary" are not 
supposed to be runned, we used them to create the most of the graphs in 
the paper. They are not automatized, to run they need some manual 
support.
-----------------------------------------------------------------------